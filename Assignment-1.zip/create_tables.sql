/* Wipe the slate clean - remove old data structures first */
DROP TABLE IF EXISTS comments CASCADE;
DROP TABLE IF EXISTS submissions CASCADE;
DROP TABLE IF EXISTS subreddits CASCADE;
DROP TABLE IF EXISTS authors CASCADE;

/* User Profiles - Where we track Reddit personas */
CREATE TABLE authors (
    id TEXT PRIMARY KEY,  
    retrieved_on BIGINT,  -- When we grabbed this info (timestamp style)
    name TEXT UNIQUE NOT NULL,  -- Actual username you see on screen
    created_utc BIGINT,  
    link_karma INTEGER,  
    comment_karma INTEGER,  -- Internet points from remarks
    profile_img TEXT,  -- Avatar image URL
    profile_color TEXT,  
    profile_over_18 BOOLEAN  
);

/* Community Spaces - Subreddit home bases */
CREATE TABLE subreddits (
    banner_background_image TEXT,  
    created_utc BIGINT,  
    description TEXT,  -- Official "what we're about" text
    display_name TEXT UNIQUE NOT NULL,  
    header_img TEXT,  -- Community logo image
    hide_ads BOOLEAN,  
    id TEXT PRIMARY KEY,  
    over18 BOOLEAN,  -- Adults-only content flag
    public_description TEXT,  -- Quick intro blurb
    retrieved_utc BIGINT,  
    name TEXT,  
    subreddit_type TEXT,  
    subscribers INTEGER, 
    title TEXT,  
    whitelist_status TEXT  -- Approved content creator status
);

/* Main Posts - The bread and butter of Reddit */
CREATE TABLE submissions (
    downs INTEGER,  -- Disapproval votes count
    url TEXT,  
    id TEXT PRIMARY KEY,  
    edited TEXT,  
    num_reports INTEGER,  
    created_utc BIGINT,  -- Post creation moment
    name TEXT, 
    title TEXT,  -- Headline that grabs attention
    author TEXT,  
    permalink TEXT,  -- Permanent web address
    num_comments INTEGER,  
    likes TEXT,  
    subreddit_id TEXT,  --  community ID
    ups INTEGER  
);

/* Conversation Threads - Where debates happen */
CREATE TABLE comments (
    distinguished TEXT,  
    downs INTEGER,  
    created_utc BIGINT,  -- Comment  timestamp
    controversiality INTEGER,  
    edited BOOLEAN,  
    gilded INTEGER,  
    author_flair_css_class TEXT,  
    id TEXT PRIMARY KEY,  -- Unique comment fingerprint
    author TEXT,  -- Commenter's hidden ID
    retrieved_on BIGINT,  
    score_hidden BOOLEAN,  
    subreddit_id TEXT,  -- Community home base ID
    score INTEGER,  -- Net upvotes-downvotes
    name TEXT,  
    author_flair_text TEXT,  -- User title text
    link_id TEXT,  -- Parent post ID
    archived BOOLEAN,  
    ups INTEGER,  
    parent_id TEXT,  
    subreddit TEXT,  -- Community display name
    body TEXT  -- The actual message content
);