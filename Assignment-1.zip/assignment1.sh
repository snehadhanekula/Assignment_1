#!/bin/bash

# Timekeeper starts
START_MOMENT=$SECONDS

echo "-------------------------------------"
echo "🚀 Launching Data Pipeline..."
echo "-------------------------------------"

# Phase 1: Foundation Construction
echo "Creating Tables..."
echo "🛠️  Phase 1: Creating the tables..."
psql -U postgres -d postgres -f create_tables.sql

# Phase 2: Relationship Web
echo "🧩 Phase 2: Relations get created.."
psql -U postgres -d postgres -f create_relations.sql

# Phase 3: pg_bulkload to Load Data 
echo "🌊 Phase 3: Data Incoming...Loading"
/opt/homebrew/Cellar/postgresql@14/14.16/bin/pg_bulkload -d postgres -U postgres authors.ctl
/opt/homebrew/Cellar/postgresql@14/14.16/bin/pg_bulkload -d postgres -U postgres subreddits.ctl
/opt/homebrew/Cellar/postgresql@14/14.16/bin/pg_bulkload -d postgres -U postgres submissions.ctl
/opt/homebrew/Cellar/postgresql@14/14.16/bin/pg_bulkload -d postgres -U postgres comments.ctl

# Phase 4: Queries Execution
echo "🔍 Phase 4: queries execution..."
psql -U postgres -d postgres -f queries.sql

# The total time it took to run
DURATION=$((SECONDS - START_MOMENT))
echo "🎉 Mission Accomplished!"
echo "⏱️  Total Expedition Time:  $(($DURATION / 60)) minutes and $(($DURATION % 60)) seconds"
echo "-------------------------------------"