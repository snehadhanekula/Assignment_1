-- cleaning up the previous temporary tables if they exist here
DROP TABLE IF EXISTS query1;
DROP TABLE IF EXISTS query2;
DROP TABLE IF EXISTS query3;
DROP TABLE IF EXISTS query4;
DROP TABLE IF EXISTS query5;

-- Query 1
CREATE TABLE query1 AS -- Counts the  total comments from a specific user
SELECT COUNT(*) AS "count of comments"
FROM comments 
WHERE author = 'xymemez'; -- Finds total number of comments made by user 'xymemez'

-- Query 2
CREATE TABLE query2 AS -- Analyze subreddit distribution by the type
SELECT subreddit_type AS "subreddit type",
       COUNT(*) AS "subreddit count" -- Groups subreddits by their type and counts
FROM subreddits
GROUP BY subreddit_type;

-- Query 3
CREATE TABLE query3 AS -- Top 10 most active subreddits
SELECT subreddit AS name,
       COUNT(*) AS "comments count",
       -- Identifies subreddits with most comments and their avg scores
       ROUND(AVG(score)::numeric, 2) AS "average score" -- Rounds average score
FROM comments
GROUP BY subreddit
ORDER BY COUNT(*) DESC
LIMIT 10;

-- Query 4
CREATE TABLE query4 AS
SELECT name, -- High-karma author classification
       link_karma AS "link karma",
       comment_karma AS "comment karma", -- Creates label
       CASE WHEN link_karma >= comment_karma THEN 1 ELSE 0 END AS label
FROM authors -- Identifies authors
WHERE ((link_karma + comment_karma) / 2.0) > 1000000
ORDER BY ((link_karma + comment_karma) / 2.0) DESC;

-- Query 5
CREATE TABLE query5 AS -- Deleted user activity by subreddit type
SELECT s.subreddit_type AS "sr type",
       COUNT(*) AS "comments num" -- Counts deleted user comments
FROM comments c
JOIN subreddits s ON c.subreddit_id = s.name 
-- Joins comments
WHERE c.author = '[deleted_user]'
GROUP BY s.subreddit_type;