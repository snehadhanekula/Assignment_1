-- this removes the existing foreign key constraints from the submissions
ALTER TABLE submissions DROP CONSTRAINT IF EXISTS fk_submissions_author;
ALTER TABLE submissions DROP CONSTRAINT IF EXISTS fk_submissions_subreddit;

-- now removes the existing foreign key constraints from the comments
ALTER TABLE comments DROP CONSTRAINT IF EXISTS fk_comments_author;
ALTER TABLE comments DROP CONSTRAINT IF EXISTS fk_comments_subreddit;
ALTER TABLE comments DROP CONSTRAINT IF EXISTS fk_comments_submission;
ALTER TABLE comments DROP CONSTRAINT IF EXISTS fk_comments_parent;

-- this here re-creates submission constraints
ALTER TABLE submissions ADD CONSTRAINT fk_submissions_author 
    FOREIGN KEY (author) REFERENCES authors(id) ON DELETE SET NULL;  
-- Keep submission
    
ALTER TABLE submissions ADD CONSTRAINT fk_submissions_subreddit 
    FOREIGN KEY (subreddit_id) REFERENCES subreddits(id) ON DELETE CASCADE;  
-- Delete submissions with subreddit

-- Re-create comment constraints with delete behaviors
ALTER TABLE comments ADD CONSTRAINT fk_comments_author 
    FOREIGN KEY (author) REFERENCES authors(id) ON DELETE SET NULL;  
-- this keeps comments if author removed

ALTER TABLE comments ADD CONSTRAINT fk_comments_subreddit 
    FOREIGN KEY (subreddit_id) REFERENCES subreddits(id) ON DELETE CASCADE;  
-- this deletes the comments with subreddit

ALTER TABLE comments ADD CONSTRAINT fk_comments_submission 
    FOREIGN KEY (link_id) REFERENCES submissions(id) ON DELETE CASCADE;  
-- this remove comments if submission deleted

ALTER TABLE comments ADD CONSTRAINT fk_comments_parent 
    FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE;  
-- finally delete the thread branches