#!/bin/bash

# Define variables
DB_NAME="postgres"
USER="postgres"
CSV_PATH="${1:-$(dirname "$0")}" 

# Drop existing tables if they exist (optional)
psql -U $USER -d $DB_NAME -c "DROP TABLE IF EXISTS query1, query2, query3, query4, query5, comments, submissions, authors, subreddits CASCADE;"

echo "Dropped existing tables."

# Create tables
#psql -U $USER -d $DB_NAME --variable=CSV_PATH="'$CSV_PATH'" -f create_tables.sql
psql -U $USER -d $DB_NAME -f create_tables.sql
echo "Tables created."


# Define relationships and constraints
psql -U $USER -d $DB_NAME -f create_relations.sql
echo "Constraints and foreign keys added."


echo "Data loaded into tables."

# Run queries
psql -U $USER -d $DB_NAME -f queries.sql
echo "Queries executed and tables query1-query5 created."

echo "Assignment 1 setup complete!"

