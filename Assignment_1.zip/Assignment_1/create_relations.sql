--Adding Foreign Key Constraint

ALTER TABLE authors DROP CONSTRAINT IF EXISTS unq_name;
ALTER TABLE subreddits DROP CONSTRAINT IF EXISTS uni_name;
ALTER TABLE subreddits DROP CONSTRAINT IF EXISTS uni_display_name;

ALTER TABLE authors
ADD CONSTRAINT unq_name UNIQUE(name);

ALTER TABLE subreddits
ADD CONSTRAINT uni_name UNIQUE(name),
ADD CONSTRAINT uni_display_name UNIQUE(display_name);

ALTER TABLE submissions
ADD CONSTRAINT fk_submissions_authors_name 
FOREIGN KEY (author) REFERENCES authors(name) 
ON DELETE SET NULL;

ALTER TABLE submissions 
ADD CONSTRAINT fk_submissions_subreddit_id 
FOREIGN KEY (subreddit_id) REFERENCES subreddits(name) 
ON DELETE SET NULL;

ALTER TABLE comments 
ADD CONSTRAINT fk_comments_subreddit_id 
FOREIGN KEY (subreddit_id) REFERENCES subreddits(name) 
ON DELETE SET NULL;

ALTER TABLE comments 
ADD CONSTRAINT fk_comments_subreddit_name 
FOREIGN KEY (subreddit) REFERENCES subreddits(display_name)
ON DELETE SET NULL;

ALTER TABLE comments 
ADD CONSTRAINT fk_comments_author 
FOREIGN KEY (author) REFERENCES authors(name)
ON DELETE SET NULL;