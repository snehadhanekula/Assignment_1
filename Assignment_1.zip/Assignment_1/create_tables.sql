-- Creating Tables
DROP TABLE IF EXISTS authors CASCADE;
CREATE TABLE authors (
    id TEXT PRIMARY KEY,
    retrieved_on INTEGER,
    name TEXT UNIQUE NOT NULL,
    created_utc INTEGER,
    link_karma INTEGER,
    comment_karma INTEGER,
    profile_img TEXT,
    profile_color TEXT,
    profile_over_18 BOOLEAN
);

DROP TABLE IF EXISTS subreddits CASCADE;
CREATE TABLE subreddits (
    banner_background_image TEXT,
    created_utc TEXT,
    description TEXT,
    display_name TEXT ,
    header_img TEXT,
    hide_ads TEXT,
    id TEXT PRIMARY KEY,
    over_18 BOOLEAN,
    public_description TEXT,
    retrieved_utc INTEGER,
    name TEXT ,
    subreddit_type TEXT,
    subscribers TEXT,
    title TEXT,
    whitelist_status TEXT
);

DROP TABLE IF EXISTS submissions CASCADE;
CREATE TABLE submissions (
    downs TEXT,
    url TEXT,
	id TEXT PRIMARY KEY,
    edited BOOLEAN,
    num_reports INTEGER,
    created_utc INTEGER,
    name TEXT,
    title TEXT,
    author TEXT,
    permalink TEXT,
    num_comments INTEGER,
    likes BOOLEAN,
    subreddit_id TEXT,
    ups INTEGER
);


DROP TABLE IF EXISTS comments CASCADE;
CREATE TABLE comments (
    distinguished TEXT,
    downs INTEGER,
    created_utc INTEGER,
    controversiality TEXT,
    edited TEXT,
    gilded TEXT,
    author_flair_css_class TEXT,
	id TEXT,
    author TEXT,
    retrieved_on INTEGER,
    score_hidden BOOLEAN,
	subreddit_id TEXT,
    score INTEGER,
    name TEXT,
    author_flair_text TEXT,
    link_id TEXT,
    archived TEXT,
    ups INTEGER,
    parent_id TEXT,
    subreddit TEXT,
    body TEXT
);



\copy authors FROM 'authors.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';


\copy submissions FROM 'submissions.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';


\copy subreddits FROM 'subreddits.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';


\copy comments FROM 'comments.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';
